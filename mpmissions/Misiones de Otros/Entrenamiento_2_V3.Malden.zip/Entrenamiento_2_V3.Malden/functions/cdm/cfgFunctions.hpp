#define addf(fname) class fname {headerType = -1;}

class cdmfnc {
	tag = "cdm";
	class cdm {
		file = "functions\cdm\fnc";
		addf(popupTarget);
        addf(spawnAITarget);
	};
};
